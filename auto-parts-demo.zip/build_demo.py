"""生成固定、完全虚构的数据和可离线使用的演示文件，不调用任何业务API。"""
from pathlib import Path
from datetime import datetime
import base64, csv, json, re, subprocess, zipfile
from PIL import Image, ImageDraw, ImageFont
from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill, Alignment

ROOT = Path(__file__).resolve().parent
AS_OF = '2026-10-10T09:00:00+08:00'

def products():
    # sku,name,warehouse,demand,hand,reserved,lead components,safety,MOQ,carton,new,stale
    rows = [
      ('BP-US-001','刹车片（示例车型A）','US-WH',10,50,10,7,25,5,10,100,20,False,False),
      ('OF-US-001','机油滤清器','US-WH',4,330,10,5,17,3,7,60,12,False,False),
      ('SP-US-001','火花塞','US-WH',3,10,2,5,22,3,10,60,10,False,False),
      ('WP-US-001','发动机水泵','US-WH',2,60,10,10,30,5,14,30,12,False,False),
      ('IC-US-001','点火线圈','US-WH',2,1010,10,7,25,3,10,50,10,False,False),
      ('SF-US-001','空气滤清器','US-WH',6,180,10,7,25,5,10,60,12,False,True),
      ('AF-RU-001','空气滤芯','RU-WH',12,30,6,15,35,5,15,120,24,False,False),
      ('BR-RU-001','安装支架','RU-WH',1,25,5,10,25,5,14,20,10,False,False),
      ('NS-RU-001','新品传感器','RU-WH',0,20,0,10,30,5,14,30,10,True,False),
      ('OS-RU-001','氧传感器','RU-WH',5,0,0,10,40,5,15,50,10,False,False),
    ]
    ps,stocks=[],[]
    for i,(sku,name,wh,daily,hand,reserved,p,t,r,safe,moq,carton,new,stale) in enumerate(rows):
        ps.append(dict(sku=sku,name=name,warehouse=wh,part_number=f'DEMO-PART-{i+1:03}',
          barcode=f'DEMO-SKU-{i+1:04}',unit='件',sold7=daily*7,sold30=daily*30,
          purchase_days=p,transit_days=t,receiving_days=r,safety_days=safe,review_days=7,
          moq=moq,carton=carton,new_product=new,supplier_id=f'DEMO-SUP-{i%3+1}',
          description='完全虚构；非真实车型适配或厂商编号'))
        stocks.append(dict(sku=sku,warehouse=wh,on_hand=hand,reserved=reserved,
          updated_at='2026-10-08T09:00:00+08:00' if stale else '2026-10-10T08:55:00+08:00'))
    return ps,stocks

def make_orders(ps):
    rows=[]
    for i in range(1,31):
        p=ps[(i-1)%len(ps)]
        platform='Ozon' if p['warehouse']=='RU-WH' else ['Amazon','eBay','独立站'][i%3]
        quantities={1:2,2:1,3:3,4:2,5:1,7:2}
        rows.append(dict(channel=platform,store_id=f'DEMO-{platform}-STORE',
          order_id=f'DEMO-ORD-{i:03}',line_id='1',sku=p['sku'],quantity=quantities.get(i,1+i%3),
          warehouse=p['warehouse'],status='cancelled' if i in (20,30) else 'awaiting_shipment',
          revision=1,updated_at='2026-10-10T08:40:00+08:00'))
    return rows

def create_label(shipment, index):
    image=Image.new('RGB',(1300,660),'white')
    draw=ImageDraw.Draw(image)
    font=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',42)
    lines=['DEMO TEST LABEL - NOT A REAL SHIPMENT',
      f"ORDER: {shipment['order_id']}",f"SKU: {shipment['label_sku']}",
      f"QTY: {shipment['label_quantity']}"]
    if shipment['label_tracking']:
        lines.append(f"TRACKING: {shipment['label_tracking']}")
    lines.append('QUANTITY IS LABEL TEXT ONLY')
    for n,line in enumerate(lines): draw.text((45,35+n*90),line,font=font,fill='black')
    path=ROOT/'labels'/f'label-{index:02}.png'
    image.save(path)
    result=subprocess.run(['tesseract',str(path),'stdout','-l','eng','--psm','6'],
      capture_output=True,text=True,check=True)
    text=result.stdout
    def find(pattern):
        m=re.search(pattern,text,re.M)
        return m.group(1) if m else None
    qty=find(r'^QTY:\s*(\d+)\s*$')
    extracted=dict(sku=find(r'^SKU:\s*([A-Z0-9-]+)\s*$'),
       quantity=int(qty) if qty else None,tracking=find(r'^TRACKING:\s*([A-Z0-9]+)\s*$'))
    assert extracted==dict(sku=shipment['label_sku'],quantity=shipment['label_quantity'],
      tracking=shipment['label_tracking']), (path,text,extracted)
    (ROOT/'ocr_text'/f'label-{index:02}.txt').write_text(text)
    shipment.update(extracted=extracted,label_path=f'labels/label-{index:02}.png',
      label_image='data:image/png;base64,'+base64.b64encode(path.read_bytes()).decode(),
      ocr_engine='Tesseract eng, psm=6；生成时真实读取模拟标签')

def make_shipments(orders):
    scenarios=[(1,'BP-US-001',2,'DEMOUS000001','正常字段'),
      (2,'WP-US-001',1,'DEMOUS000002','错发SKU'),
      (3,'SP-US-001',1,'DEMOUS000003','数量不符'),
      (4,'NEW-UNKNOWN-999',2,'DEMOUS000004','未知SKU'),
      (5,'IC-US-001',1,None,'缺少物流单号'),
      (7,'AF-RU-001',2,'DEMORU000007','正常俄罗斯订单')]
    result=[]
    for i,(oid,sku,quantity,tracking,name) in enumerate(scenarios,1):
        order=orders[oid-1]
        s=dict(shipment_id=f'DEMO-SHIP-{i:03}',order_id=order['order_id'],
          sku=order['sku'],quantity=order['quantity'],
          tracking=f"DEMO{'RU' if order['warehouse']=='RU-WH' else 'US'}{oid:06}",
          label_sku=sku,label_quantity=quantity,label_tracking=tracking,scenario=name)
        create_label(s,i)
        result.append(s)
    return result

def write_csv(filename, rows):
    if not rows: return
    with (ROOT/'csv'/filename).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)

def tables(data, results):
    yesno=lambda x:'是' if x else '否'
    return {
      '01商品主档':[{'内部SKU':p['sku'],'商品名称':p['name'],'仓库':p['warehouse'],
        '零件号':p['part_number'],'模拟条码':p['barcode'],'单位':p['unit'],
        '近7天销量':p['sold7'],'近30天销量':p['sold30'],'采购天数':p['purchase_days'],
        '运输天数':p['transit_days'],'上架天数':p['receiving_days'],'安全天数':p['safety_days'],
        '复查周期天数':p['review_days'],'最小起订量':p['moq'],'每箱件数':p['carton'],
        '是否新品':yesno(p['new_product']),'供应商':p['supplier_id']} for p in data['products']],
      '02平台SKU映射':[{'平台':m['channel'],'店铺':m['store_id'],'平台SKU':m['platform_sku'],
        '内部SKU':m['sku']} for m in data['mappings']],
      '03订单明细':[{'平台':o['channel'],'店铺':o['store_id'],'订单号':o['order_id'],
        '订单行':o['line_id'],'SKU':o['sku'],'数量':o['quantity'],'仓库':o['warehouse'],
        '状态':o['status'],'源版本':o['revision'],'源更新时间':o['updated_at']} for o in results['orders']],
      '04库存快照':[{'SKU':s['sku'],'仓库':s['warehouse'],'在库':s['on_hand'],
        '占用':s['reserved'],'可售':s['on_hand']-s['reserved'],'更新时间':s['updated_at']} for s in data['inventory']],
      '05在途采购':[{'采购单号':s['purchase_id'],'SKU':s['sku'],'仓库':s['warehouse'],
        '数量':s['quantity'],'距到货天数':s['days_until_arrival'],'状态':s['status']} for s in data['inbound']],
      '06发货核对':[{'发货编号':r['shipment_id'],'订单号':r['order_id'],'订单SKU':r['expected_sku'],
        '识别SKU':r['extracted_sku'],'订单数量':r['expected_quantity'],'标签数量':r['extracted_quantity'],
        '识别单号':r['tracking'],'核对状态':r['status'],'异常':';'.join(r['issues']),
        '数量证据':r['quantity_source'],'人工已确认':'否'} for r in results['shipments']],
      '07补货计算':[{'SKU':r['sku'],'仓库':r['warehouse'],'日均需求':r['daily_demand'],
        '总提前期':r['lead_days'],'可售':r['available'],'已确认在途':r['confirmed_inbound'],
        '目标库存':r['target_stock'],'库存位置':r['inventory_position'],'原始补货量':r['raw_quantity'],
        '建议采购量':r['order_quantity'],'预计缺货第几天':r['first_gap_day'],'决策':r['decision'],
        '理由':r['reason'],'公式版本':r['formula_version']} for r in results['replenishments']],
      '08采购草稿':[{'草稿编号':r['draft_id'],'SKU':r['sku'],'仓库':r['warehouse'],
        '采购数量':r['quantity'],'状态':r['status'],'已提交通途':'否'} for r in results['purchases']],
      '09广告建议':[{'SKU':r['sku'],'广告编号':r['campaign_id'],'平台':r['platform'],
        '建议':r['action'],'理由':r['reason'],'状态':r['status'],'已执行':'否'} for r in results['ads']],
      '10广告对象':[{'广告编号':c['id'],'平台':c['platform'],'关联SKU':','.join(c['skus']),
        '原日预算':c['daily_budget'],'币种':c['currency'],'备注':'模拟对象，不调用广告接口'} for c in data['campaigns']],
    }

def workbook(data_tables):
    wb=Workbook();intro=wb.active;intro.title='先读说明'
    for row in [ ['汽配运营Agent模拟数据：所有数据完全虚构'],
      ['模拟基准时间',AS_OF],['用途','导入飞书、演示工作流、核对公式'],
      ['真实性','不含真实客户信息、真实订单或真实物流单号'],
      ['照片识别','PNG模拟标签已用OCR读取；数量来自标签，不验证箱内数量'],
      ['采购和广告','只生成草稿或建议，不向任何平台执行'],
      ['时间','始终按固定模拟时间计算；不能拿当前时间判这些记录过期'],
      ['下一步','按零基础操作说明先使用离线网页，再导入CSV到飞书'] ]:intro.append(row)
    for name,rows in data_tables.items():
        ws=wb.create_sheet(name)
        ws.append(list(rows[0]))
        for row in rows:ws.append(list(row.values()))
        ws.freeze_panes='A2';ws.auto_filter.ref=ws.dimensions
    for ws in wb:
        for cell in ws[1]:
            cell.font=Font(color='FFFFFF',bold=True);cell.fill=PatternFill('solid',fgColor='155E75')
        for column in ws.columns:
            letter=column[0].column_letter
            ws.column_dimensions[letter].width=min(56,max(16,max(len(str(c.value or '')) for c in column)+3))
        for row in ws:
            for c in row:c.alignment=Alignment(vertical='top',wrap_text=True)
    wb.save(ROOT/'汽配Agent模拟数据.xlsx')

def main():
    for d in ['labels','ocr_text','csv','reports']:(ROOT/d).mkdir(exist_ok=True)
    ps,stocks=products();orders=make_orders(ps)
    events=orders+[dict(orders[i],status='shipped',revision=2,
      updated_at='2026-10-10T08:50:00+08:00') for i in [0,6]]+[dict(orders[0])]
    mappings=[]
    seen=set()
    for o in orders:
        key=(o['channel'],o['store_id'],o['sku'])
        if key not in seen:
            seen.add(key);mappings.append(dict(channel=key[0],store_id=key[1],sku=key[2],
              platform_sku=f'DEMO-{key[0]}-{key[2]}'))
    inbound=[dict(purchase_id=f'DEMO-IN-{i+1:03}',sku=sku,warehouse=wh,
      quantity=q,days_until_arrival=days,status='confirmed') for i,(sku,wh,q,days) in enumerate([
        ('BP-US-001','US-WH',100,12),('SP-US-001','US-WH',120,2),
        ('AF-RU-001','RU-WH',400,20),('BR-RU-001','RU-WH',100,5),
        ('OS-RU-001','RU-WH',500,90)])]
    campaigns=[dict(id=f'DEMO-AD-{i+1:03}',platform='Ozon' if p['warehouse']=='RU-WH' else 'Amazon Ads',
      skus=[p['sku']],daily_budget=1000 if p['warehouse']=='RU-WH' else 30,
      currency='RUB' if p['warehouse']=='RU-WH' else 'USD') for i,p in enumerate(ps)]
    campaigns[7]['skus']=['BR-RU-001','NS-RU-001'];campaigns.pop(8)
    data=dict(as_of=AS_OF,simulation=True,formula_version='DEMO-v1',products=ps,inventory=stocks,
      order_events=events,mappings=mappings,inbound=inbound,
      shipments=make_shipments(orders),campaigns=campaigns)
    raw=ROOT/'data.json';raw.write_text(json.dumps(data,ensure_ascii=False,indent=2))
    subprocess.run(['node',str(ROOT/'run_demo.js')],cwd=ROOT,check=True)
    results=json.loads((ROOT/'reports'/'results.json').read_text())
    ts=tables(data,results)
    for name,rows in ts.items():write_csv(name+'.csv',rows)
    workbook(ts)
    template=(ROOT/'template.html').read_text()
    encoded=json.dumps(data,ensure_ascii=False).replace('<','\\u003c')
    page=template.replace('/*ENGINE*/',(ROOT/'engine.js').read_text()).replace('/*DATA*/',encoded)
    (ROOT/'双击打开演示.html').write_text(page)
    # 打包不包含缓存、重复压缩包或浏览器验证截图。
    with zipfile.ZipFile(ROOT/'汽配Agent模拟包.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file() and p.suffix not in ('.zip','.pyc') and '__pycache__' not in p.parts and p.name!='browser-check.png':
                z.write(p,p.relative_to(ROOT))
    print(json.dumps({'products':len(ps),'order_rows':len(results['orders']),
      'label_ocr_passed':len(data['shipments']),'purchase_drafts':len(results['purchases']),
      'csv_files':len(ts),'output':str(ROOT)},ensure_ascii=False))

if __name__=='__main__':main()
