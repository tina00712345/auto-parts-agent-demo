'use strict';
const fs=require('fs');
const path=require('path');
const engine=require('./engine.js');
const data=JSON.parse(fs.readFileSync(path.join(__dirname,'data.json'),'utf8'));
const results=engine.runAll(data);
fs.mkdirSync(path.join(__dirname,'reports'),{recursive:true});
fs.writeFileSync(path.join(__dirname,'reports','results.json'),JSON.stringify(results,null,2));
const bySku=Object.fromEntries(results.replenishments.map(r=>[r.sku,r]));
const summary={mode:'仅模拟；无外部调用',as_of:data.as_of,orders:results.orders.length,
  sync:results.sync,label_checks:results.shipments.length,
  matched_labels:results.shipments.filter(s=>s.issues.length===0).length,
  abnormal_labels:results.shipments.filter(s=>s.issues.length>0).length,
  procurement_drafts:results.purchases.length,
  procurement_pieces:results.purchases.reduce((n,p)=>n+p.quantity,0),
  ad_actions:results.ads.reduce((a,r)=>(a[r.action]=(a[r.action]||0)+1,a),{}),
  purchase_quantities:Object.fromEntries(Object.entries(bySku).map(([sku,r])=>[sku,r.order_quantity]))};
fs.writeFileSync(path.join(__dirname,'reports','summary.json'),JSON.stringify(summary,null,2));
console.log(JSON.stringify(summary,null,2));
