"""在真实 Chromium 中检查离线演示的关键交互。"""
from pathlib import Path
import json
from functools import partial
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from threading import Thread
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parent

def main():
    checks=[]
    def check(name, condition):
        assert condition,name
        checks.append(name)
    class QuietHandler(SimpleHTTPRequestHandler):
        def log_message(self, *args):
            pass
    server=ThreadingHTTPServer(('127.0.0.1',0),partial(QuietHandler,directory=str(ROOT)))
    Thread(target=server.serve_forever,daemon=True).start()
    origin=f'http://127.0.0.1:{server.server_port}'
    with sync_playwright() as p:
        browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
        context=browser.new_context(viewport={'width':1440,'height':1000},accept_downloads=True)
        # 托管浏览器禁止file://，用内部回环HTTP加载同一文件；不改变浏览器管理策略。
        context.route('**/*',lambda route:route.continue_() if route.request.url.startswith(origin+'/')
          else route.abort())
        page=context.new_page();errors=[];network=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.on('request',lambda r:network.append(r.url) if r.url.startswith(('http://','https://'))
          and not r.url.startswith(origin+'/') else None)
        page.goto(origin+'/%E5%8F%8C%E5%87%BB%E6%89%93%E5%BC%80%E6%BC%94%E7%A4%BA.html')
        check('离线打开初始订单为0',page.locator('#count-orders').inner_text()=='0')
        page.locator('#run').click()
        check('流程得到30订单、4异常、4草稿、3暂停建议',
          [page.locator('#'+x).inner_text() for x in ['count-orders','count-issues','count-purchases','count-ads']]==['30','4','4','3'])
        page.locator('#sync').click()
        check('再次同步新增0更新0且总数30','新增0，更新0，忽略33，总数30' in page.locator('#status').inner_text())
        page.locator('[data-tab="shipments"]').click()
        check('6张内嵌标签图片成功载入',page.locator('.shipment img').count()==6 and
          page.locator('.shipment img').evaluate_all('(images)=>images.every(i=>i.complete && i.naturalWidth>0)'))
        page.locator('[data-confirm="0"]').click()
        check('正常标签可以模拟人工确认','人工已确认' in page.locator('.shipment').nth(0).inner_text())
        page.locator('[data-confirm="1"]').click()
        check('错误SKU不能直接确认','无法确认：SKU与订单不符' in page.locator('#status').inner_text())
        page.locator('#sku-1').fill('OF-US-001')
        page.locator('[data-confirm="1"]').click()
        check('纠正模拟SKU后确认，异常数变为3',page.locator('#count-issues').inner_text()=='3')
        page.locator('#tracking-4').fill('DEMOUS000005')
        page.locator('[data-confirm="4"]').click()
        check('补齐单号后确认，异常数变为2',page.locator('#count-issues').inner_text()=='2')
        page.locator('[data-tab="purchases"]').click()
        page.locator('[data-approve="0"]').click()
        check('模拟批准不提交且防止重复点击',page.locator('[data-approve="0"]').is_disabled()
          and '模拟已批准，未提交' in page.locator('#panel').inner_text())
        page.locator('[data-tab="ads"]').click()
        page.locator('[data-ad="0"]').click()
        check('广告评估仍为未执行',page.locator('[data-ad="0"]').inner_text()=='已模拟评估'
          and '未执行' in page.locator('#panel').inner_text())
        with page.expect_download() as downloaded:page.locator('#export').click()
        download=downloaded.value
        exported=json.loads(Path(download.path()).read_text())
        check('导出含核对和模拟审批且所有广告未执行',len(exported['manual_confirmations'])==3
          and len(exported['simulated_approvals'])==1 and all(not a['executed'] for a in exported['results']['ads']))
        page.reload()
        page.locator('[data-tab="purchases"]').click()
        check('刷新保留本地模拟审批',page.locator('[data-approve="0"]').is_disabled())
        page.locator('#run').click()
        check('重跑不重复采购草稿且保留审批',page.locator('#count-purchases').inner_text()=='4'
          and page.locator('[data-approve="0"]').is_disabled())
        page.locator('[data-tab="replenishment"]').click()
        page.screenshot(path=str(ROOT/'reports'/'browser-check.png'),full_page=True)
        page.set_viewport_size({'width':390,'height':844})
        check('移动尺寸没有整页横向溢出',page.evaluate('document.documentElement.scrollWidth<=window.innerWidth'))
        page.locator('#reset').click()
        check('重置清空操作和订单',page.locator('#count-orders').inner_text()=='0'
          and page.evaluate('localStorage.getItem("auto-parts-demo-v1")') is None)
        check('没有外部网络请求或脚本错误',not network and not errors)
        browser.close()
    server.shutdown();server.server_close()
    report={'browser':'Chromium','self_contained':True,'external_requests':len(network),
      'load_method':'内部回环HTTP；当前托管浏览器策略禁止file://，未修改策略',
      'passed':len(checks),'failed':0,'checks':checks}
    (ROOT/'reports'/'browser_validation.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
    print(json.dumps(report,ensure_ascii=False,indent=2))

if __name__=='__main__':main()
