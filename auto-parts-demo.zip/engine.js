(function (root) {
  'use strict';
  const ceil = n => Math.ceil(n - 1e-9);
  const round = n => Math.round(n * 100) / 100;
  function syncOrders(events, state = {}) {
    let created = 0, updated = 0, ignored = 0;
    for (const e of events) {
      const key = [e.channel, e.store_id, e.order_id, e.line_id].join('|');
      const old = state[key];
      if (!old) { state[key] = {...e}; created++; }
      else if (e.revision > old.revision) { state[key] = {...e}; updated++; }
      else { ignored++; }
    }
    return {state, created, updated, ignored, total: Object.keys(state).length};
  }
  function replenishment(product, stock, inbound, asOf) {
    const out = {sku: product.sku, warehouse: product.warehouse, product_name: product.name,
      daily_demand: null, lead_days: null, safety_days: product.safety_days,
      review_days: product.review_days, available: null, confirmed_inbound: null,
      target_stock: null, inventory_position: null, raw_quantity: null, order_quantity: null,
      first_gap_day: null, coverage_days: null, late_inbound: false,
      decision: '人工检查', reason: '', formula_version: 'DEMO-v1', recommendation_only: true};
    if (!stock) {out.reason='缺少库存记录'; return out;}
    const age = (new Date(asOf)-new Date(stock.updated_at))/60000;
    if (!Number.isFinite(age) || age < 0 || age > 60) {out.reason='库存数据超过60分钟或时间异常'; return out;}
    const checks = [stock.on_hand, stock.reserved, product.sold7, product.sold30,
      product.purchase_days, product.transit_days, product.receiving_days,
      product.safety_days, product.review_days, product.moq, product.carton];
    if (checks.some(n => !Number.isFinite(n) || n < 0) || product.carton < 1 ||
        !Number.isInteger(product.carton) || !Number.isInteger(product.moq) || stock.reserved > stock.on_hand) {
      out.reason='库存、需求或采购参数不合法'; return out;
    }
    if (product.new_product) {out.reason='新品缺少稳定销量，请人工制定首批数量'; return out;}
    const daily = Math.max(product.sold7/7, product.sold30/30);
    if (daily <= 0) {out.reason='没有可用需求历史，不能推断无需补货'; return out;}
    const lead = product.purchase_days + product.transit_days + product.receiving_days;
    if (!Number.isInteger(lead) || lead < 1) {out.reason='总提前期必须是正整数天'; return out;}
    const arrivals = inbound.filter(x => x.sku===product.sku && x.warehouse===product.warehouse && x.status==='confirmed');
    if (arrivals.some(x => !Number.isInteger(x.days_until_arrival) || x.days_until_arrival < 1 ||
        !Number.isFinite(x.quantity) || x.quantity <= 0)) {
      out.reason='在途到货日期或数量不明确，请采购核对'; return out;
    }
    const available = stock.on_hand-stock.reserved;
    const confirmed = arrivals.reduce((s,x)=>s+x.quantity,0);
    const target = ceil(daily*(lead+product.safety_days+product.review_days));
    const position = available+confirmed;
    const raw = Math.max(0, target-position);
    const quantity = raw > 0 ? ceil(Math.max(raw,product.moq)/product.carton)*product.carton : 0;
    let running = available, firstGap = null;
    for (let day=1;day<=lead;day++) {
      // 到货按该日开始计入，随后扣除当天需求；预测不计尚未下单的采购。
      running += arrivals.filter(x=>x.days_until_arrival===day).reduce((s,x)=>s+x.quantity,0);
      running -= daily;
      if (running < -1e-9 && firstGap === null) firstGap = day;
    }
    const late = arrivals.some(x=>x.days_until_arrival>lead+product.safety_days+product.review_days);
    Object.assign(out, {daily_demand:round(daily), lead_days:lead, available,
      confirmed_inbound:confirmed, target_stock:target, inventory_position:position,
      raw_quantity:raw, order_quantity:quantity, first_gap_day:firstGap,
      coverage_days:round(available/daily), late_inbound:late,
      decision:quantity>0?'生成采购草稿':'暂不新增采购',
      reason: quantity>0?'按目标库存、MOQ及箱规计算':'已确认库存位置覆盖目标，避免重复下单'});
    if (firstGap !== null) out.reason += `；第${firstGap}天预计出现缺口，需催货或调拨`;
    if (late) out.reason += '；存在晚到在途，先核实或催货，不能当作当前可售库存';
    return out;
  }
  function adRecommendation(r, campaign) {
    let action='建议维持', reason='到新采购提前期内未预测到库存缺口';
    if (r.order_quantity === null) {action='人工检查';reason=r.reason;}
    else if (!campaign || campaign.skus.length !== 1) {action='人工检查';reason='广告缺失或覆盖多个SKU，需要运营确认操作范围';}
    else if (r.first_gap_day !== null && r.coverage_days <= 7) {
      action='建议暂停';reason=`当前库存覆盖${r.coverage_days}天，第${r.first_gap_day}天预计缺货`;
    } else if (r.first_gap_day !== null) {
      action='建议降低预算';reason=`第${r.first_gap_day}天预计缺货，建议运营评估控制投放`;
    }
    return {sku:r.sku, warehouse:r.warehouse, campaign_id:campaign?campaign.id:'',
      platform:campaign?campaign.platform:'', action, reason, executed:false,
      status:'待运营审批（模拟）', recommendation_only:true};
  }
  function verifyShipment(expected, extracted, knownSkus) {
    const issues=[];
    if (!extracted.sku) issues.push('SKU无法读取');
    else if (!knownSkus.includes(extracted.sku)) issues.push('SKU未建档');
    else if (extracted.sku !== expected.sku) issues.push('SKU与订单不符');
    if (extracted.quantity === null) issues.push('标签数量无法读取');
    else if (extracted.quantity !== expected.quantity) issues.push('标签数量与订单不符');
    if (!extracted.tracking) issues.push('物流单号缺失');
    else if (extracted.tracking !== expected.tracking) issues.push('物流单号与发货记录不符');
    return {shipment_id:expected.shipment_id, order_id:expected.order_id,
      expected_sku:expected.sku, extracted_sku:extracted.sku,
      expected_quantity:expected.quantity, extracted_quantity:extracted.quantity,
      tracking:extracted.tracking, status:issues.length?'异常待核对':'字段匹配，待人工核对',
      issues, confirmed:false, quantity_source:'标签文字，不代表实际内件数量'};
  }
  function runAll(data) {
    const sync=syncOrders(data.order_events);
    const replenishments=data.products.map(p=>replenishment(p,
      data.inventory.find(s=>s.sku===p.sku && s.warehouse===p.warehouse),data.inbound,data.as_of));
    const ads=replenishments.map(r=>adRecommendation(r,data.campaigns.find(c=>c.skus.includes(r.sku))));
    const shipments=data.shipments.map(s=>verifyShipment(s,s.extracted,data.products.map(p=>p.sku)));
    const purchases=replenishments.filter(r=>r.order_quantity>0).map(r=>({
      draft_id:`DEMO-PO-${r.sku}-${r.warehouse}`, sku:r.sku, warehouse:r.warehouse,
      quantity:r.order_quantity, status:'待采购审批（模拟）', submitted:false, executed:false}));
    return {orders:Object.values(sync.state), sync:{created:sync.created,updated:sync.updated,
      ignored:sync.ignored,total:sync.total}, shipments, replenishments, purchases, ads};
  }
  const api={syncOrders,replenishment,adRecommendation,verifyShipment,runAll};
  if(typeof module!=='undefined'&&module.exports) module.exports=api;
  else root.DemoEngine=api;
})(typeof globalThis!=='undefined'?globalThis:this);
