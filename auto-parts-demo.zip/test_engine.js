'use strict';
const test=require('node:test');
const assert=require('node:assert/strict');
const fs=require('fs');
const E=require('./engine.js');
const d=JSON.parse(fs.readFileSync(`${__dirname}/data.json`,'utf8'));
const results=E.runAll(d);
const get=sku=>results.replenishments.find(r=>r.sku===sku);

test('订单更新和迟到事件按版本合并；重跑不重复',()=>{
  const first=E.syncOrders(d.order_events);
  assert.equal(first.total,30);assert.equal(first.updated,2);assert.equal(first.ignored,1);
  assert.equal(Object.values(first.state).find(x=>x.order_id==='DEMO-ORD-001').status,'shipped');
  const second=E.syncOrders(d.order_events,first.state);
  assert.deepEqual([second.created,second.updated,second.ignored,second.total],[0,0,33,30]);
});
test('销量、覆盖周期、库存位置和采购数量符合手算',()=>{
  const r=get('BP-US-001');
  assert.deepEqual([r.daily_demand,r.lead_days,r.target_stock,r.inventory_position,r.order_quantity],[10,37,540,140,400]);
});
test('MOQ和箱规同时满足；未用四舍五入少买',()=>{
  assert.equal(get('SP-US-001').order_quantity,60);
  assert.equal(get('WP-US-001').order_quantity,84);
  assert.equal(get('AF-RU-001').order_quantity,504);
});
test('库存充分时不因为MOQ创建多余采购',()=>{
  assert.equal(get('OF-US-001').order_quantity,0);
  assert.equal(get('IC-US-001').order_quantity,0);
});
test('库存低但及时到货时不会仅按数量建议暂停广告',()=>{
  assert.equal(get('SP-US-001').first_gap_day,null);
  assert.equal(results.ads.find(a=>a.sku==='SP-US-001').action,'建议维持');
});
test('晚到在途避免重复下单，仍揭示当前缺口',()=>{
  const r=get('OS-RU-001');assert.equal(r.order_quantity,0);
  assert.equal(r.first_gap_day,1);assert.equal(r.late_inbound,true);
  assert.equal(results.ads.find(a=>a.sku==='OS-RU-001').action,'建议暂停');
});
test('新品和过期库存不被计算成无需补货',()=>{
  assert.equal(get('NS-RU-001').order_quantity,null);
  assert.equal(get('SF-US-001').order_quantity,null);
});
test('未确认采购不计入库存位置',()=>{
  const p=d.products[0],s=d.inventory[0];
  const r=E.replenishment(p,s,d.inbound.map(x=>({...x,status:'draft'})),d.as_of);
  assert.equal(r.confirmed_inbound,0);assert.equal(r.order_quantity,500);
});
test('入库当天先到货再出库，临界库存耗尽不提前算缺货',()=>{
  const p={...d.products[0],sold7:7,sold30:30,purchase_days:1,transit_days:1,receiving_days:1};
  const s={...d.inventory[0],on_hand:1,reserved:0};
  const arrivals=[{sku:p.sku,warehouse:p.warehouse,quantity:10,days_until_arrival:2,status:'confirmed'}];
  assert.equal(E.replenishment(p,s,arrivals,d.as_of).first_gap_day,null);
  assert.equal(E.replenishment(p,s,[],d.as_of).first_gap_day,2);
});
test('无销量历史和占用超出在库时均要求人工检查',()=>{
  const p=d.products[0],s=d.inventory[0];
  assert.equal(E.replenishment({...p,sold7:0,sold30:0},s,[],d.as_of).order_quantity,null);
  assert.equal(E.replenishment(p,{...s,reserved:51},[],d.as_of).order_quantity,null);
});
test('逾期在途不被当作已入库',()=>{
  const p=d.products[0],s=d.inventory[0];
  const inbound=[{sku:p.sku,warehouse:p.warehouse,quantity:100,days_until_arrival:0,status:'confirmed'}];
  assert.equal(E.replenishment(p,s,inbound,d.as_of).order_quantity,null);
});
test('6张真实OCR读取的合成标签检出4项异常，正常标签仍需人工确认',()=>{
  assert.equal(results.shipments.length,6);
  assert.equal(results.shipments.filter(s=>s.issues.length).length,4);
  assert.deepEqual(results.shipments[1].issues,['SKU与订单不符']);
  assert.deepEqual(results.shipments[2].issues,['标签数量与订单不符']);
  assert.deepEqual(results.shipments[3].issues,['SKU未建档']);
  assert.deepEqual(results.shipments[4].issues,['物流单号缺失']);
  assert.ok(results.shipments.every(s=>s.confirmed===false));
});
test('多SKU广告必须核实范围，所有广告执行标记均为false',()=>{
  assert.equal(results.ads.find(a=>a.sku==='BR-RU-001').action,'人工检查');
  assert.ok(results.ads.every(a=>a.executed===false));
});
test('采购草稿ID重跑稳定且不自动提交',()=>{
  const second=E.runAll(d);
  assert.deepEqual(second.purchases.map(x=>x.draft_id),results.purchases.map(x=>x.draft_id));
  assert.ok(second.purchases.every(x=>x.submitted===false&&x.executed===false));
});
